/**
 * @mixinFunction
 * @polymer
 */

export const ChartsMethods = (superClass) => class extends superClass {    
}