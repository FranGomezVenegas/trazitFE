export const sopPaneIconAndBadge_icons={
    iconGreen:'./images/SOPs/SOP_OK.png',
    iconRed:'./images/SOPs/SOP_NOT_OK.png',
};    

  
