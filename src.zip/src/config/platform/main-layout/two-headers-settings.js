export const main_layout={
    display_headertwo: true,
    display_header: false,
    display_left_pane: false,
    display_center: true,
};

export const center_layout={
    display_second_header: false,
    display_tabs: true,
};